package com.example.project1_1;

public class Nutrition implements Program {

    private String type ;

    public void type(String type) {
        this.type = type;
    }
    public String getType(){return type;}

    public Nutrition(String type) {
        this.type = type;
    }

    public Nutrition() {
        this("null");
    }

    @Override
    public String toString() {
        return   type ;
    }
}

package com.example.project1_1;

public class Workout implements Program {
    private  String type ;

    public void type(String type){
        this.type = type;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return   type ;
    }

    public Workout(String type) {
        this.type = type;
    }

    public Workout() {
        this("null");
    }
}

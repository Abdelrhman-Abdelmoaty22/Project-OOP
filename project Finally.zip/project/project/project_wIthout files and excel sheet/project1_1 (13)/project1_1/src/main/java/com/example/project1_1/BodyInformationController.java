package com.example.project1_1;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Scanner;

public class BodyInformationController implements Initializable {
    HomePage nextPage = new HomePage();

    @FXML
    private Label wrongInputForAge;
    @FXML
    private Label fillAllData;
    @FXML
    private Label wrongInputForHeight;
    @FXML
    private Label wrongInputForWeight;
    @FXML
    private ComboBox<String> trainingLevel;
    @FXML
    private ComboBox<String> gender;
    @FXML
    private ComboBox<String> target;
    @FXML
    private TextField age;
    @FXML
    private TextField weight;
    @FXML
    private TextField height;

    private Trainer t1 = new Trainer();
    private ArrayList<Trainer> trainers = new ArrayList<>();
    private final File read = new File("try.txt");
    private final File write = new File("newTry.txt");
    private ArrayList<Nutrition> nutritions = new ArrayList<>();
    private ArrayList<Workout>  workouts= new ArrayList<>();
    private ArrayList<Supplements> supplements = new ArrayList<>();

    private String[] arr = new String[3];
    private  int id;

    public BodyInformationController() throws FileNotFoundException {

        Scanner in = new Scanner(read);
        Scanner input = new Scanner(write);
        String hi = null;
        String hello ;
        String[] arr1 ;
        while (in.hasNextLine()) {
            hi = in.nextLine();
        }
        if (hi != null) {
            arr = hi.split(",");
        }
        System.out.println(Arrays.toString(arr));
        while(input.hasNextLine()){
            hello = input.nextLine();
            arr1 = hello.split(",");
            trainers.add(new Trainer(arr1[0],arr1[1],arr1[6],arr1[5],arr1[7],Double.parseDouble(arr1[3]),Double.parseDouble(arr1[4]),Integer.parseInt(arr1[2])));
            nutritions.add(new Nutrition(arr1[8]));
            supplements.add(new Supplements(arr1[9]));
            workouts.add(new Workout(arr1[10]));
        }
        System.out.println(trainers);
        if(isInteger()){
            id = Integer.parseInt(arr[0]);
        }else{
            t1.setUser(arr[0]);
            t1.setPassword(arr[1]);
        }
    }




    @FXML
    void getBodyInformation(MouseEvent event) throws IOException {
        HomePage nextPage = new HomePage();
            if(!age.getText().isEmpty() &&
                    !weight.getText().isEmpty() &&
                    !height.getText().isEmpty() &&
                    target.getValue() != null &&
                    gender.getValue() != null &&
                    trainingLevel.getValue() != null){
                if(!t1.isValidInteger(age.getText()) || !t1.isValidDouble(weight.getText()) || !t1.isValidDouble(height.getText())){
                    fillAllData.setText(t1.wrong());
                }else {
                    if(!t1.checkAge(Integer.parseInt(age.getText()))){
                        wrongInputForAge.setText("Age between 18 and 120");
                        wrongInputForWeight.setText("");
                        wrongInputForHeight.setText("");
                        fillAllData.setText("");
                    } else if(!t1.checkWeight(Double.parseDouble(weight.getText()))){
                        wrongInputForAge.setText("");
                        wrongInputForWeight.setText("Weight between 30 and 300");
                        wrongInputForHeight.setText("");
                        fillAllData.setText("");
                    }else if(!t1.checkHeight(Double.parseDouble(height.getText()))){
                        wrongInputForAge.setText("");
                        wrongInputForWeight.setText("");
                        wrongInputForHeight.setText("Height between 50 and 300");
                        fillAllData.setText("");
                    }else{
                        if(isInteger()){
                            trainers.get(id).setAge(Integer.parseInt(age.getText()));
                            trainers.get(id).setWeight(Double.parseDouble(weight.getText()));
                            trainers.get(id).setHeight(Double.parseDouble(height.getText()));
                            trainers.get(id).setGender(gender.getValue());
                            trainers.get(id).setTarget(target.getValue());
                            trainers.get(id).setTrainingLevel(trainingLevel.getValue());
                            enter();
                            PrintWriter pw1 = new PrintWriter(read);
                            pw1.print(id);
                            pw1.close();
                            nextPage.changeScene("Programs.fxml");
                        }else{
                            t1.setAge(Integer.parseInt(age.getText()));
                            t1.setWeight(Double.parseDouble(weight.getText()));
                            t1.setHeight(Double.parseDouble(height.getText()));
                            t1.setGender(gender.getValue());
                            t1.setTarget(target.getValue());
                            t1.setTrainingLevel(trainingLevel.getValue());
                            trainers.add(t1);
                            nutritions.add(new Nutrition());
                            supplements.add(new Supplements());
                            workouts.add(new Workout());
                            enter();
                            PrintWriter pw1 = new PrintWriter(read);
                            pw1.print(trainers.size()-1);
                            pw1.close();
                            nextPage.changeScene("Subscriptions.fxml");
                        }
                    }

                }
            }
            else {
                fillAllData.setText("Fill All The Data");
            }
        }


    @FXML
    void goBack(MouseEvent event) throws IOException {
        if(isInteger()){
            nextPage.changeScene("Programs.fxml");
        }else
            nextPage.changeScene("Main-Page.fxml");
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        trainingLevel.getItems().addAll("BMR",
                "No exercise/week",
                "1-3 exercise/week",
                "4-5 exercise/week",
                "Daily or high intense 3-4 exercise/week",
                "Intense 6-7 exercise/week",
                "Daily high intense exercise");
        gender.getItems().addAll("Male","Female");
        target.getItems().addAll("Maintenance","Bulking","Cutting");
    }

    private boolean isInteger(){
        return arr.length == 1;
    }
    private void enter() {
        int i = 0;
        try  {
            PrintWriter pw = new PrintWriter(write);
            for(Trainer trainer:trainers){
                trainers.get(i).setType(nutritions.get(i));
                trainers.get(i).setType(workouts.get(i));
                trainers.get(i).setType(supplements.get(i));
                pw.println(trainer.toString()+i);
                i++;
            }
            pw.close();
        }catch (IOException e){
            System.out.println("Hello");
        }
    }
}

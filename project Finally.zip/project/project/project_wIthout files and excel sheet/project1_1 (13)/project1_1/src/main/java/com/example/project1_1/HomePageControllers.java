package com.example.project1_1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import java.io.IOException;
import java.util.Scanner;


public class HomePageControllers {
    HomePage nextPage = new HomePage();
    Trainer t1 = new Trainer();

    @FXML
    private Label wrongInput;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private Label success;
    File write = new File("newTry.txt");

    ArrayList<Trainer> trainers = new ArrayList<>();
    private ArrayList<Integer> try1 = new ArrayList<>();


    public HomePageControllers() throws FileNotFoundException {
        Scanner input = new Scanner(write);
        String hello;
        String[] arr1 = new String[15];
        while(input.hasNextLine()){
            hello = input.nextLine();
            arr1 = hello.split(",");
            try1.add(Integer.parseInt(arr1[arr1.length-1]));
            trainers.add(new Trainer(arr1[0],arr1[1],arr1[6],arr1[5],arr1[7],Double.parseDouble(arr1[3]),Double.parseDouble(arr1[4]),Integer.parseInt(arr1[2])));
        }
    }

    public void userSignIn(ActionEvent event) throws IOException{
        checkLogIn();
    }
    public void userSignUp(ActionEvent event) throws IOException {
        checkSignUp();
    }


    private void checkLogIn() throws IOException {
            if (isHere()) {//mtnsa4 t7ot limit ll pass
                wrongInput.setText("");
                success.setText("Signed In Successfully.");
                nextPage.changeScene("Programs.fxml");//elmfrod baa nzbt de b7es eno yft7 3la page mo3yna ka signed in user baa lakn myft74 el signout page de mynf34 tba page da zorar
            }
            else if (username.getText().isEmpty() || password.getText().isEmpty()) {
                wrongInput.setText("Dear Customer Complete The Data.");
                success.setText("");
            }
            else {
                wrongInput.setText("Wrong Username Or Password.");
                success.setText("");
            }
     }


    private void checkSignUp() throws IOException {
        if (username.getText().isEmpty() || password.getText().isEmpty()) {
            wrongInput.setText("Dear Customer Complete The Data.");
        }
        else{
            if(!t1.checkPassword(password.getText())){
                wrongInput.setText(t1.wrongPassword());
            }

            else{
               if(isHere()){
                   wrongInput.setText("You are already have account please sign up");
                   success.setText("");
               }
               else{
                   wrongInput.setText("");
                   success.setText("Success.");

                   try  {
                       File  steady = new File("try.txt");
                       PrintWriter pw = new PrintWriter(steady);
                       pw.print(username.getText() + "," + password.getText());
                       pw.close();
                   }catch (IOException e){
                       System.out.println("Hello");
                   }
                   nextPage.changeScene("Body-Information-Page.fxml");
               }
            }
        }
    }

    private boolean isHere(){
        for(int i = 0;i< trainers.size();i++){
            if (username.getText().toString().equals(trainers.get(i).getUser()) && password.getText().toString().equals(trainers.get(i).getPassword())) {//mtnsa4 t7ot limit ll pass
                try {
                    File  steady = new File("try.txt");
                    PrintWriter pw = new PrintWriter(steady);
                    pw.print(try1.get(i));
                    pw.close();
                }catch (IOException e){
                    System.out.println("Hello");
                }
                return true;
            }
        }
        return false;
    }
}

package com.example.project1_1;

public interface Program {
    void type(String type);
    String getType();
}

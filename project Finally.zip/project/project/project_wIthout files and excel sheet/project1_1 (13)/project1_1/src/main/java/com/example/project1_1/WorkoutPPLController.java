package com.example.project1_1;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class WorkoutPPLController {
    HomePage nextPage = new HomePage();
    @FXML
    void push(MouseEvent event) throws IOException {
        nextPage.changeScene("Push-Workout.fxml");
    }
    @FXML
    void pull(MouseEvent event) throws IOException {
        nextPage.changeScene("Pull-Workout.fxml");
    }
    @FXML
    void legs(MouseEvent event) throws IOException {
        nextPage.changeScene("Legs-Workout.fxml");
    }
    @FXML
    void backToWorkouts(MouseEvent event) throws IOException {
        nextPage.changeScene("Workout-PPL.fxml");
    }
    @FXML
    void backToPrograms(MouseEvent event) throws IOException {
        nextPage.changeScene("Programs.fxml");
    }
}

package com.example.project1_1;

public class Supplements implements Program{
    private String type ;
    public void type(String type){
        this.type = type;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return   type ;
    }
    public Supplements(String type) {
        this.type = type;
    }

    public Supplements() {
        this("null");
    }
}

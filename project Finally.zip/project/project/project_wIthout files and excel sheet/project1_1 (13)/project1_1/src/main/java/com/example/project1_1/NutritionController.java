package com.example.project1_1;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class NutritionController {
    HomePage nextPage = new HomePage();
    @FXML
    void backToPrograms(MouseEvent event) throws IOException {
        nextPage.changeScene("Programs.fxml");
    }
}

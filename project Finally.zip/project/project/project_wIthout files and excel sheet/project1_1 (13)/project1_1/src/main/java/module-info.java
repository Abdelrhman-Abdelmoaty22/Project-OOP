module com.example.project1_1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.project1_1 to javafx.fxml;
    exports com.example.project1_1;
}
package com.example.project1_1;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Scanner;

public class SubscriptionController implements Initializable {
    @FXML
    private ComboBox<String> workout;
    @FXML
    private ComboBox<String> nutrition;
    @FXML
    private ComboBox<String> supplement;
    @FXML
    private Label fillAllData;
    @FXML
    private Label atLeastOne;
    private  int id;
    private final File read = new File("try.txt");
    private final File write = new File("newTry.txt");
    ArrayList<Trainer> trainers = new ArrayList<>();
    private ArrayList<Nutrition> nutritions = new ArrayList<>();
    private ArrayList<Workout>  workouts= new ArrayList<>();
    private ArrayList<Supplements> supplements = new ArrayList<>();

    HomePage nextPage = new HomePage();

    public SubscriptionController() throws FileNotFoundException {

        Scanner in = new Scanner(read);
        Scanner input = new Scanner(write);
        String hi = null;
        String hello ;
        String[] arr1 ;
        while (in.hasNextLine()) {
            hi = in.nextLine();
        }
        if(hi != null)
         id = Integer.parseInt(hi);
        while(input.hasNextLine()){
            hello = input.nextLine();
            arr1 = hello.split(",");
            trainers.add(new Trainer(arr1[0],arr1[1],arr1[6],arr1[5],arr1[7],Double.parseDouble(arr1[3]),Double.parseDouble(arr1[4]),Integer.parseInt(arr1[2])));
            nutritions.add(new Nutrition(arr1[8]));
            supplements.add(new Supplements(arr1[9]));
            workouts.add(new Workout(arr1[10]));
        }
    }
    @FXML
    void chooseFromSubscription(MouseEvent event) throws IOException {
        if(workout.getValue() != null &&
                nutrition.getValue() != null &&
                supplement.getValue() != null){
            if(workout.getValue().equals("No Workout")&&nutrition.getValue().equals("No Nutrition")&&supplement.getValue().equals("No Supplements")){
                atLeastOne.setText("Choose at least one");
                fillAllData.setText("");
            }else if(workout.getValue().equals("No Workout")&&nutrition.getValue().equals("No Nutrition")){
                supplements.get(id).type(supplement.getValue());
                workouts.get(id).type("null");
                nutritions.get(id).type("null");
                enter();
                nextStep();
            }else if(workout.getValue().equals("No Workout")&&supplement.getValue().equals("No Supplements")){
                nutritions.get(id).type(nutrition.getValue());
                supplements.get(id).type("null");
                workouts.get(id).type("null");
                enter();
                nextStep();
            }else if(supplement.getValue().equals("No Supplements")&&nutrition.getValue().equals("No Nutrition")){
                workouts.get(id).type(workout.getValue());
                supplements.get(id).type("null");
                nutritions.get(id).type("null");
                enter();
                nextStep();
            }else if(workout.getValue().equals("No Workout")){
                supplements.get(id).type(supplement.getValue());
                nutritions.get(id).type(nutrition.getValue());
                workouts.get(id).type("null");
                enter();
                nextStep();
            }else if(nutrition.getValue().equals("No Nutrition")){
                supplements.get(id).type(supplement.getValue());
                workouts.get(id).type(workout.getValue());
                nutritions.get(id).type("null");
                enter();
                nextStep();
            }else if(supplement.getValue().equals("No Supplements")){
                workouts.get(id).type(workout.getValue());
                nutritions.get(id).type(nutrition.getValue());
                supplements.get(id).type("null");
                enter();
                nextStep();
            }else{
                workouts.get(id).type(workout.getValue());
                supplements.get(id).type(supplement.getValue());
                nutritions.get(id).type(nutrition.getValue());
                enter();
                nextStep();
            }
        }else{
            fillAllData.setText("Fill All The Data");
            atLeastOne.setText("");
        }
    }

    @FXML
    void goBack(MouseEvent event) throws IOException {
        nextPage.changeScene("Main-Page.fxml");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        workout.getItems().addAll("No Workout","Workout");
        nutrition.getItems().addAll("No Nutrition","Nutrition");
        supplement.getItems().addAll("No Supplements","Supplement");
    }
    
    private void nextStep() throws IOException {
        nextPage.changeScene("Programs.fxml");
    }

    private void enter() {
        try  {
            PrintWriter pw = new PrintWriter(write);

            int i = 0;
            for(Trainer trainer:trainers){
                trainers.get(i).setType(nutritions.get(i));
                trainers.get(i).setType(workouts.get(i));
                trainers.get(i).setType(supplements.get(i));
                pw.println(trainer.toString()+i);
                i++;
            }
            PrintWriter pw1 = new PrintWriter(read);
            pw1.print(id);
            pw1.close();
            pw.close();
        }catch (IOException e){
            System.out.println("Hello");
        }
    }
}

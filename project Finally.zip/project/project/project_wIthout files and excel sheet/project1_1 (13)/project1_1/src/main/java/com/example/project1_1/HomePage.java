package com.example.project1_1;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//Note: section
/*
#GUI#
=consists of: stage > scene > scene-graph
    -Stage: the window of app
    -Scene: added to stage and is drawing surface
    -scene-graph: hold and arrange nodes

-nodes: everything we add
*/

public class HomePage extends Application {

    public static void main(String[] args) {
        launch(args);//it calls the start method to run app
    }
    private static Stage stg;//fake stage and used to change scene
    @Override
    public void start(Stage primaryStage) throws Exception {
        //this is the start method and it is automatically called after starting from the main method
        //and when the start method is called then it creates a new stage
        //which is called the primaryStage and u can rename it frommthe function
        //you can create new stage too like this
        //Stage stage1= new Stage();//create new stage

        //**CREATE THE MAIN WINDOW**
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Main-Page.fxml"));//connect the main fxml file
        Parent root = loader.load();
        Scene scene = new Scene(root);//create scene and add the root node and it need at least one node
        primaryStage.setScene(scene);//add scene to stage

        //Set window name
        primaryStage.setTitle("Coaching Core");//add title

        //Close the application when the user presses ESC + Screen Constrains
        primaryStage.setFullScreenExitHint("press 'ESC' to Exit");//message will apear when program run
//        primaryStage.setFullScreen(true);//auto full screen
        scene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                Platform.exit();
            }
        });

        //m4faker bta3et e
        Group rootGroup = new Group(root);
        scene.setRoot(rootGroup);

        // Add icon to app
        List<Image> icons = new ArrayList<>();
        icons.add(new Image("file:D:\\Education\\computer science\\semester 3\\oop\\OOP Project\\project 1.1\\project1_1\\src\\main\\resources\\com\\example\\project1_1\\img\\lockIcon.png"));
        primaryStage.getIcons().addAll(icons);

        primaryStage.show();//to show stage

        //Switch to second page
        stg = primaryStage;
//        primaryStage.setResizable(false);
    }

    //lma el homepagecontroller t4t8l wy5o4 b2a fe signin/up hycall elfunction de 34an y8yr el fxml
    public void changeScene(String fxml) throws IOException{
        Parent pane = FXMLLoader.load(getClass().getResource(fxml));//connect the second page and fxml is the file you passed
        stg.getScene().setRoot(pane);//show the page
    }

}
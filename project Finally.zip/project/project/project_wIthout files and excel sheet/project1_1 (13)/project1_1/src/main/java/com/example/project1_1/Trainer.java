package com.example.project1_1;

import java.time.LocalDate;
import java.time.Period;

public class Trainer {
    private String user;
    private String password;

    public Trainer() {
    }

    public Trainer(String user, String password, String target, String gender, String trainingLevel, double weight, double height, int age) {
        this.user = user;
        this.password = password;
        this.target = target;
        this.gender = gender;
        this.trainingLevel = trainingLevel;
        this.weight = weight;
        this.height = height;
        this.age = age;
    }

    private String target;
    private String gender;
    private String trainingLevel;
    private double weight;
    private double height;

    private int age;

    private double calories;

    private Nutrition nutrition;
    private Workout workout;
    private Supplements supplements;

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isValidDouble(String st){
        try{
            Double.parseDouble(st);
            return st.matches("[-]?[0-9]*\\.?[0-9]+");
        }catch (NumberFormatException e){
            return false;
        }
    }

    public boolean isValidInteger(String st){
        try{
            Integer.parseInt(st);
            return true;
        }catch (NumberFormatException e){
            return false;
        }
    }


    public String wrong(){
        return "Must be digit not Alphabetical";
    }
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
            this.password = password;
    }

    public boolean checkPassword(String password){
        return password.length() >= 8 ;
    }


    public boolean checkAge(int age){
        return age<=120&&age>=18;
    }

    public boolean checkHeight(double height){
        return height>=50&&height<=300;
    }

    public boolean checkWeight(double weight){
        return weight>=30&&weight<=300;
    }

    public String wrongPassword(){
        return "Password must be more 8 char or more";
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTrainingLevel() {
        return trainingLevel;
    }

    public void setTrainingLevel(String trainingLevel) {
        this.trainingLevel = trainingLevel;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public int getAge() {
        return age;
    }


    @Override
    public String toString() {
        return this.getUser() + "," + this.getPassword()+","+this.getAge()+","+this.getWeight()+","+this.getHeight()+","+this.getGender()+","+this.getTarget()+","+this.getTrainingLevel()+","+this.getNutrition()+","+this.getSupplements()+","+this.getWorkout()+",";
    }

    public double getCalories(){
        if(this.gender.equals("Male")){
            this.calories = 10*weight + 6.25*height - 5*age+5;
        }else{
            this.calories = 10*weight + 6.25*height - 5*age-161;
        }
        return calories;
    }

    public void setType(Program p){
        if(p instanceof Workout){
            this.workout = (Workout) p;
        } else if (p instanceof Nutrition) {
            this.nutrition = (Nutrition) p;
        }else if(p instanceof  Supplements){
            this.supplements = (Supplements) p;
        }
    }

    public Trainer(String user, String password, String target, String gender, String trainingLevel, double weight, double height, int age, Workout workout, Nutrition nutrition, Supplements supplements) {
        this.user = user;
        this.password = password;
        this.target = target;
        this.gender = gender;
        this.trainingLevel = trainingLevel;
        this.weight = weight;
        this.height = height;
        this.age = age;
        this.nutrition = nutrition;
        this.workout = workout;
        this.supplements= supplements;
    }

    public Nutrition getNutrition() {
        return nutrition;

    }

    public Workout getWorkout() {
        return workout;
    }

    public Supplements getSupplements() {
        return supplements;
    }
}

package com.example.project1_1;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.Scanner;

public class ProgramsController {
    HomePage nextPage = new HomePage();
    @FXML
    private Label programNotIncluded;

    private  int id;
    private final File read = new File("try.txt");
    private final File write = new File("newTry.txt");
    ArrayList<Trainer> trainers = new ArrayList<>();
    ArrayList<Nutrition> nutritions = new ArrayList<>();
    ArrayList<Workout>  workouts= new ArrayList<>();
    ArrayList<Supplements> supplements = new ArrayList<>();
    public ProgramsController() throws FileNotFoundException {

        Scanner in = new Scanner(read);
        Scanner input = new Scanner(write);
        String hi = null;
        String hello ;
        String[] arr1  ;
        while (in.hasNextLine()) {
            hi = in.nextLine();
        }
        if(hi != null)
            id = Integer.parseInt(hi);
        while(input.hasNextLine()){
            hello = input.nextLine();
            arr1 = hello.split(",");
            trainers.add(new Trainer(arr1[0],arr1[1],arr1[6],arr1[5],arr1[7],Double.parseDouble(arr1[3]),Double.parseDouble(arr1[4]),Integer.parseInt(arr1[2])));
            nutritions.add(new Nutrition(arr1[8]));
            supplements.add(new Supplements(arr1[9]));
            workouts.add(new Workout(arr1[10]));
        }
    }
    @FXML
    void workoutPage(MouseEvent event) throws IOException {
        if(!(Objects.equals(workouts.get(id).getType(), "null")))
            nextPage.changeScene("Workout-PPL.fxml");
        else{
            programNotIncluded.setText("Program not included");
        }
    }
    @FXML
    void supplementPage(MouseEvent event) throws IOException {
        //e5tar baa anhe calories 3la 7asb el callories ele gebnahalo
        if(!(Objects.equals(supplements.get(id).getType(), "null")))
            nextPage.changeScene("Supplement.fxml");
        else{
            programNotIncluded.setText("Program not included");
        }
    }
    @FXML
    void nutritionPage(MouseEvent event) throws IOException {
        if(!(Objects.equals(nutritions.get(id).getType(), "null"))){
            if(trainers.get(id).getCalories()>=1000&&trainers.get(id).getCalories()<1500){
                nextPage.changeScene("Nutrition-1000-Cal.fxml");
            }else if(trainers.get(id).getCalories()>=1500&&trainers.get(id).getCalories()<2000){
                nextPage.changeScene("Nutrition-1500-Cal.fxml");
            }else if(trainers.get(id).getCalories()>=2000&&trainers.get(id).getCalories()<2500){
                nextPage.changeScene("Nutrition-2000-Cal.fxml");
            }else if(trainers.get(id).getCalories()>=2500&&trainers.get(id).getCalories()<3000){
                nextPage.changeScene("Nutrition-2500-Cal.fxml");
            }else if(trainers.get(id).getCalories()>=3000&&trainers.get(id).getCalories()<3500){
                nextPage.changeScene("Nutrition-3000-Cal.fxml");
            }else if(trainers.get(id).getCalories()>=3500&&trainers.get(id).getCalories()<4000){
                nextPage.changeScene("Nutrition-3500-Cal.fxml");
            }else if(trainers.get(id).getCalories()>=4000&&trainers.get(id).getCalories()<4500){
                nextPage.changeScene("Nutrition-4000-Cal.fxml");
            }else if(trainers.get(id).getCalories()>=4500&&trainers.get(id).getCalories()<5000){
                nextPage.changeScene("Nutrition-4500-Cal.fxml");
            }else {
                  nextPage.changeScene("Nutrition-5000-Cal.fxml");
            }
        }
        else{
            programNotIncluded.setText("Program not included");
        }

    }
    @FXML
    void logOut(MouseEvent event) throws IOException {
        nextPage.changeScene("Main-Page.fxml");
    }
    @FXML
    void upadteBodyInformation(MouseEvent event) throws IOException {
        nextPage.changeScene("Body-Information-page.fxml");
    }
    @FXML
    void editSubscriptions(MouseEvent event) throws IOException {
        nextPage.changeScene("Subscriptions.fxml");
    }

}
